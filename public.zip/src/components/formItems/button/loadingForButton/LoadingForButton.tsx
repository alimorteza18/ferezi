import classes from "./LoadingForButton.module.scss"
const LoadingForButton = () => {
  return (
    <div className={classes.buttonLoading}></div>
  )
}

export default LoadingForButton